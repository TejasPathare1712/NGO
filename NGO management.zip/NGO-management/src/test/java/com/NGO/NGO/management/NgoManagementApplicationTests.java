package com.NGO.NGO.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NgoManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
