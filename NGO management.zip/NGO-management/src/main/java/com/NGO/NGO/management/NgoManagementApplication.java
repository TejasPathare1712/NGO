package com.NGO.NGO.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NgoManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(NgoManagementApplication.class, args);
	}

}
